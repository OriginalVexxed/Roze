#!/bin/bash

python3 main.py

read -p "Press Enter to continue..."
# NETCRY

<details>
<summary>Commands</summary>
<img src="https://r2.e-z.host/20aca75f-b614-4a0a-af4a-a562b0905973/e0jswi5d.png" alt="Screenshot of commands">
</details>

---

# How to contribute to this project
Create a pull request

We deeply value and appreciate the contributions of our contributors.

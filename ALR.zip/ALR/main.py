import os
import subprocess
import sys
sys.dont_write_bytecode = True
import time

import colorama
from colorama import Fore, init
from pystyle import Center, Write, Colors, Colorate

"""@wrd2vexxed and @Mxrcyfull. coded this
if you're planning on skidding this code, keep this comment please and thank you mr skid man"""

init()

options = """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃     discord.gg/jNJ3Hkhmcq       ┃     github.com/OriginalVexxed   ┃                                            
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃  [1] Mass ban                   ┃  [2] Mass create channels       ┃               
┃  [3] Delete all channels        ┃  [4] Webhook spammer            ┃            
┃  [5] Webhook deleter            ┃  [6] Nuker bot                  ┃               
┃  [7] Channel spammer            ┃  [8] Give admin to a user       ┃              
┃  [9] Channel spammer            ┃  [10] . . . . . . . . . . . . . ┃
┃  [11] . . . . . . . . . . . .   ┃  [12] . . . . . . . . . . . . . ┃ 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
"""

def banner():
    banner_text = """


███╗░░░███╗██╗░░██╗██████╗░░█████╗░██╗░░░██╗░░░██████╗░███████╗░██████╗██╗██████╗░███████╗██████╗░
████╗░████║╚██╗██╔╝██╔══██╗██╔══██╗╚██╗░██╔╝░░░██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝██╔══██╗
██╔████╔██║░╚███╔╝░██████╔╝██║░░╚═╝░╚████╔╝░░░░██║░░██║█████╗░░╚█████╗░██║██████╔╝█████╗░░██║░░██║
██║╚██╔╝██║░██╔██╗░██╔══██╗██║░░██╗░░╚██╔╝░░░░░██║░░██║██╔══╝░░░╚═══██╗██║██╔══██╗██╔══╝░░██║░░██║
██║░╚═╝░██║██╔╝╚██╗██║░░██║╚█████╔╝░░░██║░░░██╗██████╔╝███████╗██████╔╝██║██║░░██║███████╗██████╔╝
╚═╝░░░░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝░╚════╝░░░░╚═╝░░░╚═╝╚═════╝░╚══════╝╚═════╝░╚═╝╚═╝░░╚═╝╚══════╝╚═════╝░
   ░   ░ ░    ░    ░ ░    ░          ░   ░  ▒ ▒ ░░  
         ░    ░           ░ ░        ░      ░ ░     """
    print(Colorate.Diagonal(Colors.red_to_purple, banner_text, 8))

def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    os.system(f"title MxrcyFullxDesired.")
    banner()
    print(Colorate.Vertical(Colors.purple_to_red, options, 1))
    while True:
        user_input = Write.Input(f"\n\n@Mxrcyfull.""x@Desired.━>>> ", Colors.blue_to_red, interval=0.03)
        user_input = user_input.lower()
    
        if user_input == "1":
            subprocess.run(["python", "commands/massban.py"])
            time.sleep(1.9)
            main()
        elif user_input == "":
            print("Error enter something")
            time.sleep(0.7)
            main()
        elif user_input == "2":
            subprocess.run(["python", "commands/masschannel.py"])
            time.sleep(1.9)
            main()
        elif user_input == "3":
            subprocess.run(["python", "commands/massdelch.py"])
            time.sleep(1.9)
            main()
        elif user_input == "4":
            subprocess.run(["python", "commands/webhook.py"])
            time.sleep(1.9)
            main()
        elif user_input == "5":
            subprocess.run(["python", "commands/dwebhook.py"])
            time.sleep(1.9)
            main()        
        elif user_input == "6":
            subprocess.run(["python", "commands/nuker.py"])
            time.sleep(1.9)
            main()
        elif user_input == "7":
            subprocess.run(["python", "commands/tspam.py"])
            time.sleep(1.9)
            main()
        elif user_input == "8":
            subprocess.run(["python", "commands/givadmin.py"])
            time.sleep(1.9)
            main()
        elif user_input == "exit":
            sys.exit()
        else:
            print(Fore.RED +"Error 404: Command not found")
            time.sleep(0.7)
            main()

if __name__ == "__main__":
    main()
